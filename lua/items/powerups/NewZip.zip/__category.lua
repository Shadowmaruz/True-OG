CATEGORY.Name = 'Powerups'
CATEGORY.Icon = 'star'
